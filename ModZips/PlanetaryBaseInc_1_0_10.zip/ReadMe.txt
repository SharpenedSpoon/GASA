KERBAL PLANETARY BASE INC.
---------------
	This is an expansion for the stock ksp parts. It adds components for bases on other planets or even on Kerbin.
	No other mods are required for this mod to work.

INSTALLATION
---------------
	To install, simply copy the gamedata folder into your Kerbal Space Program folder.
	When you already have another version of this mod installed, delete this folder first.

CHANGE FILTER
---------------
	You can change if and where filter for this mods are added. This can be done in the "KPBS_settings.cfg" file.

LICENSING
---------------
	CC-BY-NC 
	http://creativecommons.org/licenses/by-nc/4.0/

AUTHOR
---------------
	Nils277