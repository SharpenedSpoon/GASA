-----
To allow a 100% compatibility with FilterExtentions it is recommended to set all variables in the
PlanetaryBaseInc/KPBS_settings.cfg file to false.
-----